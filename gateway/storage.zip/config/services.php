<?php
return [
    'event' => [
        'base_uri' => env('EVENT_SERVICE_BASE_URL'),
        'secret' => env('EVENT_SERVICE_SECRET'),
    ],

];